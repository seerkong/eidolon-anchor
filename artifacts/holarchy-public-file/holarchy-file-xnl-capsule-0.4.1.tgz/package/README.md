# holarchy-file-xnl-capsule

Local file authority for versioned organizations, with native XNL authoring, complete-history preview, atomic ChangeSet submission and exact-byte snapshot issuance. The capsule composes storage and pure organization logic; draft VFS, VCS and inference databases do not own organization history.

## Author and commit

```ts
import { HolarchyFileXnlCapsule } from "holarchy-file-xnl-capsule";
import { decodeOrganizationSnapshotXnl } from "holarchy-file-xnl-logic";
import { diffOrganizationStates } from "holarchy-core-logic";

const capsule = new HolarchyFileXnlCapsule({
  root: "./organization-authority",
  authorityId: "example",
});
const before = await capsule.loadOrganizationState({
  authorityId: "example", effectiveDate: "2026-01-01",
});
// editedXnl preserves before's authority, revision and effective date.
const after = decodeOrganizationSnapshotXnl(editedXnl);
const changeSet = diffOrganizationStates(before, after, "edit-1");
const execution = {
  actorRef: "local-owner", executionId: "execution-1",
  executionInstant: "2026-01-01T00:00:00Z",
};
await capsule.previewOrganizationChangeSet(changeSet, execution);
await capsule.commitOrganizationChangeSet(changeSet, execution);
```

`executeOrganizationCommands` is the domain-command entrance; `commitOrganizationChangeSet` accepts direct mutations. Both use the same full-history domain, governance and scope checks. A ChangeSet is the only atomic group. Preview neither reserves the request identity nor writes audit, journal or head. Another writer can advance the revision after preview; submission then fails CAS, requiring reload and explicit recomputation. Matching accepted retries return their recorded result; reusing the same request ID for different content is rejected.

## Scope and governance

The local capsule explicitly grants its owner full scope by default. Service hosts inject `authorization.resolveScope({authority, actorRef, effectiveDate})`, bound to trusted host identity. Request bodies are not authorization grants. Pure core write APIs require an explicit authorization port and fail closed when it is absent.

Scopes are `all`, `roots` or `deny`. Root grants cover active primary child organizations and their eligible relationships. Global member edits require every active affiliation to remain within scope. Creating a relationship cannot claim an existing outside subject. Future effective boundaries are checked as well. Partial read projections carry `coverage: "partial"` and cannot be used as complete authoring or reconciliation input.

The versioned `holarchy.constraints/v1` policy accepts only:

```xnl
rules = { roleAssignmentLimits = [{ roleId = "reviewer" maxActive = 1 }] }
```

Limits count active assignment records for the specified role in the policy's own Holon, at every relevant effective-time boundary. There is no inherited policy behavior. Unknown legacy profiles stay informational. Policy changes themselves require the same trusted scope and produce an audit record.

## Reconciliation and issuance

Inject an inference capsule into `reconcileOrganization`. For service admission, also inject `validateCandidate` using this capsule's strong preview, preserving structured domain diagnostics and propagating infrastructure failures. Results label their validation as `projection-only` or `authority-backed`; only the latter verifies complete stored history. Incomplete inference has no committable candidate. Reconciliation does not write the authority; select complete accepted groups and explicitly submit the resulting successor ChangeSet with its source evidence.

`projectOrganizationSnapshot({rootHolonRef, effectiveAt}, {maxDepth, maxRecords})` returns an issued snapshot, canonical bytes and issuance receipt. Editing authority files does not automatically update admitted resources or already running tasks. Newly issued resources must be explicitly adopted; old consumers retain their frozen facts and exact proof bytes.

## Storage and migration

New writes use native structured XNL fields, including objects and arrays. Legacy `valueJson` and domain JSON wrappers remain in compatibility readers and frozen historical fixtures; SQL JSON-column conversion stays inside the ORM adapter.

For an existing v1 authority, first call `capsule.store.migrateLegacyFormat(expectedRevision, {executionId, executionInstant})`. It verifies the old closure, adds a native revision and migration receipt, then atomically switches head. Old records, trees, receipts and issued bytes are not rewritten. Direct native writes to an unmigrated v1 head fail closed. Preserve historical bytes when backing up or moving an authority directory.

## Platform and concurrency

The tested native inference platform is macOS arm64 with Node.js 26 and Bun 1.3. File transactions publish immutable material before atomically replacing head. Writer locks publish complete candidate bytes through an exclusive hard link. On macOS, abandoned-lock recovery uses the OS advisory lock held through a permanent `.owner.reclaim.guard` file, including when several recovery processes race.

All writers and recovery processes must use this protocol on a local filesystem. Do not replace or unlink the permanent guard while the authority is in use, and do not mix older recovery implementations. Other platforms currently fail closed when automatic abandoned-lock reclamation is required; native inference distribution and additional filesystem platforms are future work.

These are release candidates. Packing and isolated installation do not mean the versions have been published to npm.
