# Shared organization scenario support

Production OrganizationState and ChangeSet data are the only organization model. `organizationScenarioCatalog()` returns native XNL documents with independently specified expected states. `decodeOrganizationScenario()` validates those documents through the public codecs; `runOrganizationScenario(runtime, scenario)` invokes supplied host ports and returns PASS, FAIL or NOT_RUN evidence, including content digest, versions, entry points and assertions.

The runner checks complete authority projections, atomic acceptance and rejection, explicit successor selection, and read-only phases. File/process hosts must supply a real path-to-digest inventory in `observeAuthority()`; missing inventory produces NOT_RUN. The host prepares the declared Base/Remote before invoking the runner. Evidence records only the host actually executed; U/F results do not claim W/E conformance.

`createSyntheticTeamFixture(options)` supplies configurable production entities for downstream integration. `createFixtureSeedChangeSet(state)` creates an explicit initial write. `issueOrganizationFixture(capsule, input)` seeds an empty authority through the public commit API and calls its real issuer, returning canonical snapshot and receipt bytes plus package provenance. The caller supplies filesystem ownership, authorization, clock, issuance bounds and actual package version.

The package has no native database, filesystem, test framework or application dependency. Conflict execution is injected through `reconcile`, so hosts can compose the real inference capsule. Each ChangeSet is one atomic group; dependencies connect groups. The oracle contains no planner, diff or apply calls.
